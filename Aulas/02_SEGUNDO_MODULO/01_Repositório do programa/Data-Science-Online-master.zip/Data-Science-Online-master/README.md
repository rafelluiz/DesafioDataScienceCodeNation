# Aceleradev DataScience Online

Entre na semana do curso que deseja para visualizar os arquivos. 
